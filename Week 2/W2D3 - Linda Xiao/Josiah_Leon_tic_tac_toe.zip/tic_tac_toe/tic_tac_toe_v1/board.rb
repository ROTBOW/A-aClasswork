class Board

    attr_reader :length

    def initialize(length=3)
        @length = length
        @grid = Array.new(length) {Array.new(length){'_'}}
    end

    def valid?(pos)
        x, y = pos
        -1 < x && x < @length && -1 < y && y < @length
    end

    def [](pos)
        x, y = pos
        @grid[x][y]
    end

    def []=(pos, val)
        x, y = pos
        @grid[x][y] = val
    end

    def empty?(pos)
        self[pos] == '_'
    end

    def place_mark(pos, mark)
        if self.valid?(pos) && self.empty?(pos)
            self[pos] = mark
        else
            raise "You broke something"
        end
    end

    def print
        @grid.each do |row|
            p row
        end
    end

    def win_row?(mark)
        @grid.each do |row|
            return true if row.all? {|ele| ele == mark }
        end
        false
    end

    def win_col?(mark)
        @grid.transpose.each do |row|
            return true if row.all? {|ele| ele == mark }
        end
        false
    end

    def win_diagonal?(mark)
        left = []
        right = []

        @grid.each_with_index do |row, idx|
            left << @grid[idx][idx]
            right << @grid[idx][@grid.length - 1 - idx]
        end

        left.all?{ |ele| ele == mark } || right.all?{ |ele| ele == mark }
    end

    def empty_positions?
        @grid.flatten.any?{ |ele| ele == '_' }
    end

    def win?(mark)
        win_row?(mark) || win_col?(mark) || win_diagonal?(mark) 
    end
end



