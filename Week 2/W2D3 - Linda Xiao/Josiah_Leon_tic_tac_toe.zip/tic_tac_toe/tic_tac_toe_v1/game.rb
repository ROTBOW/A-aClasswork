require_relative 'board.rb'
require_relative 'humanplayer.rb'

class Game

    def initialize(player1_mark, player2_mark)
        @player1 = Human_player.new(player1_mark)
        @player2 = Human_player.new(player2_mark)
        @current_player = @player1
        @board = Board.new
    end

    def switch_turn
        if @current_player == @player1
            @current_player = @player2
        else
            @current_player = @player1
        end
    end

    def play
        while @board.empty_positions?
            @board.print
            pos = @current_player.get_position
            @board.place_mark(pos, @current_player.mark)
            if @board.win?(@current_player.mark)
                p "Congats #{@current_player.mark}, you've won!"
                return
            else
                self.switch_turn
            end
        end
        p 'draw...'
    end


end