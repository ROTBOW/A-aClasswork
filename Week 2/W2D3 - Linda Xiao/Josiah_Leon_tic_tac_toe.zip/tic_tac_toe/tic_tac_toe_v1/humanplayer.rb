class Human_player
    attr_reader :mark

    def initialize(mark)
        @mark = mark
    end

    def get_position
        pos = ['a']
        nums = '0123456789'
        p "Player: #{@mark} Enter a position, for example: \'1 3\' "
        pos = gets.chomp.split(' ')
        if pos.length != 2 || !nums.include?(pos.first) || !nums.include?(pos.last)
            raise 'wrong format'
        end
        pos.map!(&:to_i)
    end
end


