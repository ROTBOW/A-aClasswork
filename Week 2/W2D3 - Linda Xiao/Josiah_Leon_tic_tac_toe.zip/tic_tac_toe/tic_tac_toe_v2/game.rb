require_relative 'board.rb'
require_relative 'humanplayer.rb'

class Game

    def initialize(size, *players)
        @players = []
        players.each do |plr_mark|
            @players << Human_player.new(plr_mark)
        end
        @current_player = @players.first
        @board = Board.new(size)
    end

    def switch_turn
        @players.push(@players.shift)
        @current_player = @players.first
    end

    def play
        while @board.empty_positions?
            @board.print
            pos = @current_player.get_position
            @board.place_mark(pos, @current_player.mark)
            if @board.win?(@current_player.mark)
                p "Congats #{@current_player.mark}, you've won!"
                return
            else
                self.switch_turn
            end
        end
        p 'draw...'
    end


end