class Board

    attr_reader :max_height

    def self.build_stacks(num)
        @board = Array.new(num) {Array.new}
    end

    def initialize(num, height)
        @max_height = height
        @stacks = Board.build_stacks(num)
        raise "rows and cols must be >= 4" if num < 4 || height < 4
    end

    def add(token, idx)
        if @stacks[idx].length < @max_height
            @stacks[idx] << token 
            return true
        else
            return false
        end
    end

    def vertical_winner?(token)
        @stacks.any? { |stack| stack.length == @max_height && stack.all? {|el| el == token} }
    end

    def horizontal_winner?(token)
        (0...@max_height).each do |i|
            return true if @stacks.all? { |stack| stack[i] == token }
        end
        false
    end

    def winner?(token)
        horizontal_winner?(token) || vertical_winner?(token)
    end

    # This Board#print method is given for free and does not need to be modified
    # It is used to make your game playable.
    def print
        @stacks.each { |stack| p stack }
    end
end
