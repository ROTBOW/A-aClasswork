class Code
  POSSIBLE_PEGS = {
    "R" => :red,
    "G" => :green,
    "B" => :blue,
    "Y" => :yellow
  }

  attr_reader :pegs

  def self.valid_pegs?(arr)
    arr.all?{ |ele| POSSIBLE_PEGS.keys.include?(ele.upcase) }
  end

  def initialize(arr)
    if Code.valid_pegs?(arr)
      @pegs = arr.map(&:upcase)
    else
      raise "Yo pegs broken"
    end
  end

  def self.random(length)
    pegs = []
    length.times { pegs << POSSIBLE_PEGS.keys.sample }
    Code.new(pegs)
  end


  def self.from_string(str)
    Code.new(str.split(''))
  end

  def [](idx)
    @pegs[idx]
  end

  def length
    @pegs.length
  end
  require 'byebug'

  def num_exact_matches(code)
    # debugger
    count = 0
    code.pegs.each_with_index do |peg, idx|
      count += 1 if peg == @pegs[idx]
    end
    count
  end

  def num_near_matches(code)
    count = 0
    code.pegs.each do |peg|
      count += 1 if @pegs.include?(peg)
    end
    count - num_exact_matches(code)
  end

  def ==(code)
    @pegs == code.pegs
  end
end
