class Board

    attr_reader :size

    def initialize(num)
        @grid = Array.new(num) { Array.new(num) {:N} }
        @size = num * num
    end

    def [](arr)
        x, y = arr
        @grid[x][y]
    end
  
    def []=(pos, val)
        x, y = pos
        @grid[x][y] = val
    end

    def num_ships
        count = 0
        @grid.each do |subArr|
            subArr.each { |ele| count += 1 if ele == :S }
        end
        count
    end

    def attack(pos)
        if self[pos] == :S
            self[pos] = :H
            p "you sunk my battleship!"
            return true
        else
            self[pos] = :X
            return false
        end
    end

    def place_random_ships
        percent = @size / 4
        size = @grid.length
        while percent > 0
            row = rand(0...size)
            col = rand(0...size)
            if self[[row, col]] != :S
                self[[row, col]] = :S
                percent -= 1
            end
        end
    end

    def hidden_ships_grid
        size = @size / 2
        new_grid = Array.new(size) {Array.new}

        @grid.each_with_index do |subArr, idx1|
            subArr.each_with_index do |ele, idx2|
                if ele == :S
                    new_grid[idx1][idx2] = :N
                else
                    new_grid[idx1][idx2] = ele
                end
            end
        end
        new_grid
    end


    def self.print_grid(grid)
        grid.each do |subArr|
            length = subArr.length - 1
            subArr.each_with_index do |ele, idx|
                print ele
                print ' ' if length != idx
            end
            puts
        end
    end

    def cheat
        Board.print_grid(@grid)
    end

    def print
        Board.print_grid(self.hidden_ships_grid)
    end

end
