require_relative 'list.rb'
require_relative 'item.rb'

class Todoboard
    attr_reader :list

    def initialize(label)
        @label = label
        @list = List.new('nope')
    end

    def get_command
        puts "What is thy bidding, my master?"
        command, *arr = gets.chomp.split(' ')
        
        case command
        when 'mktodo'
            @list.add_item(*arr)
            return true

        when 'up'
            @list.up(*arr.map(&:to_i))
            return true

        when 'down'
            @list.down(*arr.map(&:to_i))
            return true

        when 'swap'
            @list.swap(*arr.map(&:to_i))
            return true

        when 'sort'
            @list.sort_by_date!
            return true

        when 'priority'
            @list.print_priority
            return true

        when 'print'
            @list.print_full_item(*arr)
            return true

        when 'quit'
            return false
        end
    end

    def run
        until get_command == false
            get
        end
    end
end