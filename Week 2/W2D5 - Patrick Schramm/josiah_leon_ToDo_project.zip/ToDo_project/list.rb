require_relative 'item.rb'

class List
    attr_accessor :label

    def initialize(label)
        @label = label
        @items = []
    end

    def add_item(title, deadline, description='')
        if Item.valid_date?(deadline)
            @items << Item.new(title, deadline, description)
            return true
        else
            false
        end

    end

    def size
        @items.size
    end

    def valid_index?(index)
        @items[index] != nil
    end

    def swap(i_1, i_2)
        if valid_index?(i_1) && valid_index?(i_2)
            @items[i_1], @items[i_2] = @items[i_2], @items[i_1]
            return true
        else
            false
        end
    end

    def [](index)
        @items[index]
    end

    def priority
        @items.first
    end

    def print
        p "  ------------------------------------------ "
        p "                 #{@label}                   "
        p "  ------------------------------------------ "
        p "  Index | Item                 | Deadline    "
        p "  ------------------------------------------ "
         @items.each.with_index { |item, idx| p "  #{idx}   |   #{item.title}          |   #{item.deadline}" }
        p "  ------------------------------------------ "
    end

    def print_full_item(index)
        if valid_index?(index)
            eye = @items[index]
            p eye.title
            p eye.deadline
            p eye.description
        end
    end

    def print_priority
        print_full_item(0)
    end

    def up(idx, amount=1)
        while amount > 0
            if valid_index?(idx)
                swap(idx, idx-1)
                amount -= 1
                idx -= 1
            end
        end
    end

    def down(idx, amount=1)
        while amount > 0
            if valid_index?(idx)
                swap(idx, idx+1)
                amount -= 1
                idx += 1
            end
        end
    end

    def sort_by_date!
        @items.sort_by! {|item| item[:deadline] }
    end



end

