class Item

    attr_accessor :title, :deadline, :description

    def self.valid_date?(date_string)
        arr = date_string.split('-')
        month = arr[1]
        day = arr[2]
        test_1 = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12']
        test_2 = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10']
        ('11'..'31').each { |n| test_2 << n}

        if arr[0].length < 4
            return false
        end

        if !test_1.include?(month)
            return false
        end

        if !test_2.include?(day)
            return false
        end

        true
    end

    def initialize(title, deadline, description)
        if !Item.valid_date?(deadline)
            raise "Do you even know what dates are, broh?"
        end
        @title = title
        @deadline = deadline
        @description = description
    end

    def deadline=(new_deadline)
        if Item.valid_date?(new_deadline)
            @deadline = new_deadline
        end
    end

end