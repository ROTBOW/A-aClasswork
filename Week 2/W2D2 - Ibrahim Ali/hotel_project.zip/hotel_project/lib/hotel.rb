require_relative "room"

class Hotel
  attr_reader :rooms

  def initialize(name, rooms)
    @name = name
    @rooms = {}
    rooms.each do |k, v|
      @rooms[k] = Room.new(v)
    end
  end

  def name
    arr_new = @name.split(" ").map do |char|
      char.capitalize
    end
    arr_new.join(" ")
  end

  def room_exists?(name)
    @rooms.has_key?(name)
  end

  def check_in(person, name)
    if !room_exists?(name)
      p "sorry, room does not exist"
      return
    end
    if @rooms[name].add_occupant(person)
      p "check in successful"
    else
      p "sorry, room is full"
    end
  end

  def has_vacancy?
    vacant = []
    @rooms.each_value do |room|
      vacant << room.full?
    end
    !(vacant.count(true) == @rooms.keys.length)
  end

  def list_rooms
    @rooms.each do |name, room|
      puts "#{name} : #{room.available_space}"
    end
  end
end
