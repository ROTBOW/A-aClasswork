require "employee"
require "byebug"

class Startup
  attr_reader :name, :funding, :salaries, :employees

  def initialize(name, funding, salaries)
    @name = name
    @funding = funding
    @salaries = salaries
    @employees = []
  end

  def valid_title?(title)
    @salaries.has_key?(title)
  end

  def >(startup)
    @funding > startup.funding
  end

  def hire(employee_name, title)
    if self.valid_title?(title)
      @employees << Employee.new(employee_name, title)
    else
      raise "Error"
    end
  end

  def size
    @employees.length
  end

  def pay_employee(id)
    if @funding > @salaries[id.title]
      @funding -= @salaries[id.title]
      id.pay(@salaries[id.title])
    else
      raise "brokeboy lol"
    end
  end

  def payday
    @employees.each { |employee| pay_employee(employee) }
  end

  def average_salary
    arr = []
    @employees.each do |employee|
      arr << @salaries[employee.title]
    end
    return arr.sum / arr.length
  end

  def close
    @employees = []
    @funding = 0
  end

  def acquire(startup)
    @funding += startup.funding
    startup.salaries.each do |k, v|
      if !salaries.has_key?(k)
        @salaries[k] = v
      end
    end
    @employees += startup.employees
    startup.close()
  end
end
