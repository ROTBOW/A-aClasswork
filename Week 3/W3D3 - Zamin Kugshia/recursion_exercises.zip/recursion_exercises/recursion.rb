require 'byebug'
def range(start, ending)
    return [] if ending < start
    answer = []
    (start...ending).each {|i| answer << i}
    answer
end

# p range(1, 5)

def range_recur(start, ending)
    return [] if ending < start
    return [start] if start == ending - 1
    [start] + range_recur((start + 1), ending)
end

# p range_recur(1, 1)
# p range_recur(5, 1)
# p range_recur(1, 10)

# this is math, not Ruby methods.

# recursion 1
# exp(b, 0) = 1
# exp(b, n) = b * exp(b, n - 1)

# # recursion 2
# exp(b, 0) = 1
# exp(b, 1) = b
# exp(b, n) = exp(b, n / 2) ** 2             [for even n]
# exp(b, n) = b * (exp(b, (n - 1) / 2) ** 2) [for odd n]

def exp1(b, n)
    return 1 if n == 0
    b * exp1(b, n-1)
end

# p exp1(5, 2)
# p exp1(2, 2)
# p exp1(2, 0)

#2, 0 = 1
#2, 1 = 2
#2, 2
def exp2(b, n)
    return 1 if n == 0
    return b if n == 1

    if n.even?
        temp_val = exp2(b, (n/2)) 
        return temp_val * temp_val
    else
        temp_val =  b * exp2(b,(n-1)/ 2)
        return temp_val * temp_val
    end
end

# p exp2(2, 0)
# puts '-' * 10

# p exp2(2, 1)
# puts '-' * 10

# p exp2(5, 2)

# robot_parts = [
#   ["nuts", "bolts", "washers"],
#   ["capacitors", "resistors", "inductors"]
# ]

# robot_parts_copy = robot_parts.dup

# # shouldn't modify robot_parts
# robot_parts_copy[1] << "LEDs"
# # but it does
# robot_parts[1] # => ["capacitors", "resistors", "inductors", "LEDs"]

def deep_dup(arr)
    return arr if arr.length == 1
    
    # if temp_arr[0].is_a?(Array)
    #     temp_arr.shift
    #     return deep_dup(temp_arr)
    # end
    [arr[0].dup] + deep_dup(arr.drop(1))

end

# [1,2,3].drop(0) => [1, 2, 3]
# [1,2,3].drop(1) => [2, 3]
# [1,2,3].drop(2) => [3]

# robot_parts = [
#   ["nuts", "bolts", "washers"],
#   ["capacitors", "resistors", "inductors"]
# ]
# robot_parts_copy = deep_dup(robot_parts)
# robot_parts_copy[1] << "LEDs"
# # but it does
# p robot_parts_copy
# puts "--------------"
# p robot_parts # => ["capacitors", "resistors", "inductors", "LEDs"] <= this is incorrect


def fib(n)
    return [1, 1].take(n) if n <= 2

    temp_val = fib(n-1)

    temp_val + [temp_val[-1] + temp_val[-2]]

end

# p fib(0)
# p fib(1)
# p fib(2)
# p fib(3)
# p fib(10)

def bsearch(arr, key)
    # return 1 if arr.length == 0
    return nil if !arr.include?(key)
    middle = arr.length / 2
    left_side = arr[0...middle]
    right_side = arr[(middle + 1)..-1]

    if arr[middle] == key
        return left_side.length
    elsif arr[middle] < key
        (left_side.size + 1) + bsearch(right_side, key)
    else
        bsearch(left_side, key)
    end
end

# p bsearch([1,2,3,4,5,6,7,8,9,10], 4) # => 3
# p bsearch([10,12,13,14,15,16,17], 15) # => 4
# p bsearch([1, 2, 3], 1) # => 0
# p bsearch([2, 3, 4, 5], 3) # => 1
# p bsearch([2, 4, 6, 8, 10], 6) # => 2
# p bsearch([1, 3, 4, 5, 9], 5) # => 3
# p bsearch([1, 2, 3, 4, 5, 6], 6) # => 5
# p bsearch([1, 2, 3, 4, 5, 6], 0) # => nil
# p bsearch([1, 2, 3, 4, 5, 7], 6) # => nil

def merge_sort(arr) # def not quick sort
    return arr if arr.length <= 1
    pivot = [arr.first]
    right_side = arr[1..-1].select {|ele| ele > pivot.first}
    left_side = arr[1..-1].select {|ele| ele <= pivot.first}

    merge_sort(left_side) + pivot + merge_sort(right_side)
end


# p merge_sort([9, 7, 1, 10, 3, 4])
# p merge_sort([1, 2, 14 , 24, 3, 7, 10, 3])


def subsets(arr)
    return [[]] if arr.empty?

    temp_val = subsets(arr[0..-2])
    new_arr = []
    temp_val.each {|ele| new_arr << (ele + [arr[-1]])}
    
    temp_val + new_arr

end


# p subsets([]) # => [[]]
# p subsets([1]) # => [[], [1]] 
# p subsets([1, 2]) # => [[], [1], [2], [1, 2]] 
# p subsets([1, 2, 3]) # => [[], [1], [2], [1, 2], [3], [1, 3], [2, 3], [1, 2, 3]]



def permutations(arr)
    return [arr] if arr.length <= 1
    # debugger
    answer = []

    temp_val = permutations(arr[0..-2]) # => [[]]
    
    temp_val.each do |sub_temp|
        (0...arr.length).each do |i| # => 0 up to 2
            if i == 0
                answer << ([arr[-1]] + sub_temp)
            else
                answer << (sub_temp[0...i] + [arr[-1]] + sub_temp[i..-1])
            end
        end
    end
    answer
end

# hint 1: you can do the pervious pers sim to last one, can inter the same way, how its handle inside is dif
# hint 2: 


# p permutations([]) # => [[]]
# p permutations([1]) # => [[1]]
# p permutations([1, 2]) # => [[1, 2], [2, 1]] 
# p permutations([1, 2, 3]) # => [[1, 2, 3], [1, 3, 2], [2, 1, 3], [2, 3, 1], [3, 1, 2], [3, 2, 1]]

# [[2, 1], [1, 2]]
# [[3, [2, 1], [1, 2]], [[2, 1], 3, [1, 2]], [[2, 1], [1, 2], 3]]

# [1, 2, 3, 4, 5]
# [6, 1, 2, 3, 4, 5]
# [1, 6,  2, 3, 4, 5]
# [1, 2, 6, 3, 4, 5]
# [1, 2, 3, 6, 4, 5]
# [1, 2, 3, 4, 6, 5]
# [1, 2, 3, 4, 5, 6]

    # make_change(39)
    # => [25, 10, 1, 1, 1, 1]


def greedy_make_change(amount, coins = [25, 10, 5, 1])
    return [] if amount == 0

    debugger
    coins.each do |coin|
        if amount >= coin
            [coin] + greedy_make_change((amount - coin), coins )
        end
    end
    # if amount >= 25
    #     [25] + greedy_make_change((amount - 25))
    # elsif amount >= 10
    #     [10] + greedy_make_change((amount - 10))
    # elsif amount >= 5
    #     [5] + greedy_make_change((amount - 5))
    # elsif amount >= 1
    #     [1] + greedy_make_change((amount - 1))
    # end
end

 p greedy_make_change(100, [15, 7, 5, 1])
#  p greedy_make_change(77)
#  p greedy_make_change(49)
#  p greedy_make_change(14)
#  p greedy_make_change(5)