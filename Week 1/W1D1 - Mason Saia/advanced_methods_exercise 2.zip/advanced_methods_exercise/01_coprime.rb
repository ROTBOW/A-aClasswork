# Write a method, coprime?(num_1, num_2), that accepts two numbers as args.
# The method should return true if the only common divisor between the two numbers is 1.
# The method should return false otherwise. For example coprime?(25, 12) is true because
# 1 is the only number that divides both 25 and 12.


def coprime?(num_1, num_2)
    final = Hash.new(0)
    numbers = [divisors(num_1) , divisors(num_2)]
    numbers.each do |arr|
        arr.each do |num|
            final[num] += 1 
        end 
    end 
    new_arr = []
    final.each do |k,v|
        
        if v >= 2
            new_arr << k
        end
    end
    if new_arr.length != 1
        return false
     end
    true
end

def divisors(number)
    final = []
    
    (1...number).each do |i|
        if number % i == 0
            final << i
        end
    end
    final
end



p coprime?(25, 12)    # => true
p coprime?(7, 11)     # => true
p coprime?(30, 9)     # => false
p coprime?(6, 24)     # => false

# # masonsaia@Masons-MacBook-Air advanced_methods_exercise % ruby 01_coprime.rb
# [1]
# false
# [1]
# true
# [1]
# false
# [1]
# [2]
# [3]
# false