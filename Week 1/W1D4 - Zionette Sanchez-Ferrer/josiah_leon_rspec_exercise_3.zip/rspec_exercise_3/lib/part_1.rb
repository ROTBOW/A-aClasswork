def is_prime?(num)
    return false if num < 2
    (2...num).each do |number|
        if num % number == 0
            return false 
        end
    end
    true
end

def nth_prime(n)
    primes = []
    i = 2
    until primes.length == n 
        if is_prime?(i)
            primes << i
        end
        i += 1
    end
    primes[n-1]
end


def prime_range(min, max)

    (min..max).select { |num| is_prime?(num) }

end