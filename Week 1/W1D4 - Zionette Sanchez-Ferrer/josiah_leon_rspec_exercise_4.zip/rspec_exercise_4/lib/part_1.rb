def my_reject(arr, &prc)
    arr.select {|ele| !prc.call(ele)}
end

def my_one? (arr, &prc)
    cases = []
    arr.each {|ele| cases << prc.call(ele)}
    if cases.count(true) == 1
        return true
    else
        return false
    end
end

def hash_select(hash, &prc)
    hash_1 = {}
    hash.each do |k, v|
        if prc.call(k, v)
            hash_1[k] = v
        end
    end
    hash_1
end

def xor_select(arr, prc1, prc2)
    empty_arr = []
    arr.each do |ele|
        if prc1.call(ele) && !prc2.call(ele) || prc2.call(ele) && !prc1.call(ele)
            empty_arr << ele
        end
    end
    empty_arr
end

def proc_count(val, arr_prcs)
    count = 0
    arr_prcs.each do |prc|
        if prc.call(val)
            count += 1
        end
    end
    count 
end