def proper_factors(num)
    arr = []
    (1...num).each do |number|
        if num % number == 0
            arr << number
        end
    end
    arr
end

def aliquot_sum(n)
    arr = proper_factors(n)
    arr.sum
end


def perfect_number?(n)
    if aliquot_sum(n) == n
        return true
    end

    false
end


def ideal_numbers(n)
    arr = []
    i = 1
    until arr.length == n
        if perfect_number?(i)
            arr << i
        end
        i += 1
    end

    arr
end