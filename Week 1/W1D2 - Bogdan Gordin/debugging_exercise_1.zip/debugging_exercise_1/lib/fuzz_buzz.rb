# Debug this code to pass rspec! There is 1 mistake to fix.

# Write a method, fuzz_buzz, that accepts a number as an arg. 
# The method should return an array of numbers from one to the given number that are not divisible by 3 or 5.

require "byebug"

def fuzz_buzz(num)
    numbers = []

    #debugger
    (1..num).each do |i|
        if i % 3 == 0 || i % 5 == 0
          next  
        end

        numbers << i
    end

    numbers
end

print fuzz_buzz(20)