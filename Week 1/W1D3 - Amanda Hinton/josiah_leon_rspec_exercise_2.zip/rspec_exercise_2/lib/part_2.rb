def palindrome?(word)
    new_word = ''
    temp_word = word.split('') # array of each letter in word
    (0..word.length-1).each do |idx|
        new_word << temp_word.pop
    end
    new_word == word
end

def substrings(str) #don't forget this Josiah!
  arr = []

  str.each_char.with_index do |char1, idx1|
    str.each_char.with_index do |char2, idx2|
      if idx2 >= idx1
        arr << str[idx1..idx2]
      end
    end
  end
  arr
end

def palindrome_substrings(str)
  arr = substrings(str).select do |ele|
    palindrome?(ele) && ele.length > 1
  end

  arr
end



#

#     it "should return an array containing all substrings that are palindromes and longer than 1 character" do
#       expect(palindrome_substrings("abracadabra")).to match_array ["aca", "ada"]
#       expect(palindrome_substrings("madam")).to match_array ["madam", "ada"]
#       expect(palindrome_substrings("taco")).to match_array []
#     end



#  