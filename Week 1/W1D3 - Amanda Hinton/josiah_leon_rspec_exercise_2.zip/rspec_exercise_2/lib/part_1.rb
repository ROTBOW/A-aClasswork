def partition(arr, num)
  arr_1 = []
  arr_2 = []
  
  arr.each do |ele|
    if ele < num
        arr_1 << ele
    else
        arr_2 << ele
    end
  end

  [arr_1, arr_2]
end

def merge(hash_1, hash_2)
  new_hash = {}
  
  hash_1.each do |k, v|
    new_hash[k] = v
  end

  hash_2.each do |k, v|
    new_hash[k] = v
  end

  new_hash
end

def censor(sentence, curses)
  new_arr = []
  sentence = sentence.split(" ")

  sentence.each do |word|
     if curses.include?(word.downcase)
        new_arr << devowel(word)
     else
        new_arr << word
     end
    end

  new_arr.join(" ")
end


def devowel(word)
    vowels = 'aeuio'
    new_word = ''
    word.each_char do |letter|
        if vowels.include? (letter.downcase)
            new_word << '*'
        else
            new_word << letter
        end
    end
    new_word
end

#2 ** 2 = 4
#Math.sqrt ()

 def power_of_two?(number)
    return true if number == 1
  
    (1...number).each do |num|
        if 2 ** num == number
            return true
        end
    end

   false
 end
